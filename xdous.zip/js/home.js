document.addEventListener("DOMContentLoaded", function () {
  const audio = document.querySelector(".rain__mp3");
  audio.autoplay;
});
